# 🎲 RedLuck Lotto - Cryptocurrency Lottery on Solana

A complete, production-ready Telegram bot for a blockchain-based lottery system on Solana with VIP tiers, referral rewards, leaderboards, and a transparent dashboard.

## ✨ Features

### 🎯 Core Lottery
- **24/7 Operations:** Hourly draws throughout the day
- **3-Tier Prize System:** 5-match (70%), 4-match (20%), 3-match (10%)
- **Smart Rollover:** Unclaimed tiers automatically carry forward
- **Provably Fair:** Blockchain-verified randomness

### 💰 Wallet & Security
- Multi-wallet support (bot-managed, imported, external)
- Military-grade encryption for private keys
- 4-digit PIN security
- Auto-deleting sensitive messages

### 👑 VIP System & Rewards
- 5-tier membership based on spend
- Referral commissions and bonuses
- Leaderboards (top winners, active players)
- Exclusive perks for high-tier members

### 📊 Transparency Dashboard
- Real-time statistics sourced from payout_logs
- Recent draw results with winning numbers
- Winner verification with transaction signatures
- Historical data and analytics

### 🤖 AI Assistant
- Groq-powered (Llama 3.1) for instant responses
- Gameplay guidance and rule explanations
- Wallet assistance and security advice
- 24/7 support availability

## 🚀 Quick Start

### Prerequisites
- Python 3.10+
- PostgreSQL 13+
- Telegram Bot Token (from @BotFather)
- Solana wallet with private key
- Groq API key (optional, for AI)

### Installation (5 minutes)

```bash
# 1. Clone the project
git clone <repo-url>
cd redluck-lotto

# 2. Setup Python environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Setup web frontend
cd redluck-lotto-web
npm install
cd ..

# 4. Configure environment
cp .env.example .env
# Edit .env with your credentials

# 5. Run the bot
python main.py
```

**For detailed setup:** See [SETUP_GUIDE.md](./SETUP_GUIDE.md)

## 📁 Project Structure

```
redluck-lotto/
├── main.py                 # Main bot application
├── db.py                   # PostgreSQL database layer
├── encryption.py           # Private key encryption
├── email_service.py        # Email notifications
├── health_server.py        # Health monitoring
├── ai/                     # AI chat module (Groq)
│   ├── ai_client.py
│   └── prompts.py
├── redluck-lotto-web/      # React/Vite web frontend
└── requirements.txt        # Python dependencies
```

## 🎮 How to Play

1. **Start Bot:** Send `/start` to RedLuck Lotto bot
2. **Setup Wallet:** Create or import a Solana wallet
3. **Set PIN:** Create a 4-digit security PIN
4. **Buy Tickets:** Purchase tickets for 0.025 SOL each
5. **Pick Numbers:** Select 5 numbers from 1-40
6. **Wait for Draw:** Draws happen every hour
7. **Check Results:** View winners and prize distributions

## 💎 Prize Structure

| Tier | Match | Percentage | Potential Payout |
|------|-------|-----------|------------------|
| 🏆 Jackpot | 5/5 | 70% of pool | $100+ SOL |
| 🥈 Major | 4/5 | 20% of pool | $20-50 SOL |
| 🥉 Minor | 3/5 | 10% of pool | $5-20 SOL |

*Prices shown are examples. Actual payouts depend on ticket sales and rollover.*

## 👑 VIP Tiers

- **Bronze:** 0-1 SOL spent
- **Silver:** 1-5 SOL spent
- **Gold:** 5-20 SOL spent
- **Platinum:** 20-50 SOL spent
- **Diamond:** 50+ SOL spent

Each tier offers exclusive benefits and higher commission rates.

## 🔐 Security Features

- ✅ End-to-end encryption for private keys
- ✅ Solana blockchain verification
- ✅ No private keys stored unencrypted
- ✅ 4-digit PIN protection
- ✅ Secure wallet imports with auto-deletion
- ✅ Rate limiting on transactions

## 📊 Database

- **PostgreSQL** for persistent data
- **Encrypted storage** for private keys
- **Transaction logs** for every action
- **Payout tracking** for transparency
- **User statistics** and analytics

## 🌐 Web Frontend

Interactive dashboard with:
- Real-time lottery statistics
- Player leaderboards
- Wallet management interface
- Draw history and verification
- VIP tier information

Built with React + Vite for fast, responsive UX.

## 🤖 AI Integration

The bot includes a Groq-powered AI assistant that:
- Explains lottery rules and mechanics
- Guides new players
- Provides security advice
- Answers frequently asked questions
- Available 24/7

## 📈 Monitoring

Built-in health checks and monitoring:
- Database connection status
- Bot runtime verification
- Transaction queue monitoring
- Error logging and alerts

## 🚀 Deployment Options

- **Local Development:** Run on your machine
- **Docker:** Containerized deployment
- **Cloud Platforms:** Railway, Render, Heroku compatible
- **VPS:** Self-hosted on Ubuntu/Debian

## 📝 Configuration

All settings configured via `.env` file:
- Telegram credentials
- Solana RPC and wallet
- Database connection
- Email service
- AI (Groq) API key
- Announcement channels

## 🆘 Support

### Troubleshooting
1. Check `.env` is properly configured
2. Verify PostgreSQL is running
3. Test Telegram bot token
4. Review application logs

### Documentation
- See `SETUP_GUIDE.md` for detailed setup
- Review `main.py` for bot logic
- Check `ai/prompts.py` for AI configuration

## 📄 Files Included

```
Main Bot
├── main.py (7300+ lines)
├── db.py (Database layer)
├── encryption.py (Key security)
├── email_service.py (Email notifications)
├── health_server.py (Monitoring)
└── info.py (Project info)

AI Module
├── ai_client.py (Groq integration)
└── prompts.py (AI system prompts)

Web Frontend
├── React + Vite setup
├── Dashboard components
├── Responsive design
└── Real-time data binding

Configuration
├── .env.example
├── requirements.txt
└── redluck-lotto-web/package.json
```

## 🔄 Key Statistics Tracked

- Total draws completed
- Total prizes distributed
- Unique players
- Biggest jackpot
- 24-hour activity metrics
- Winner leaderboards
- VIP tier distribution

## ✅ What's Included

- ✅ Full lottery system with 3-tier prizes
- ✅ Multi-wallet support with encryption
- ✅ Solana blockchain integration
- ✅ PostgreSQL database layer
- ✅ AI-powered chat assistant
- ✅ Web dashboard and leaderboards
- ✅ Referral and reward system
- ✅ VIP tier management
- ✅ Email notification service
- ✅ Health monitoring and alerts
- ✅ Complete documentation

## 🎯 Ready for Production

This is a complete, tested implementation ready for:
- Mainnet deployment
- Real SOL transactions
- Full user operations
- Commercial use

All core features are implemented, tested, and documented.

---

**RedLuck Lotto** - Bringing fairness to blockchain gaming on Solana

*Built with Python, PostgreSQL, React, and love for Solana.*
