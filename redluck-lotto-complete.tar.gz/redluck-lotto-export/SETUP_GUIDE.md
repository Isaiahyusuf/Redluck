# 🎲 RedLuck Lotto - Complete Setup Guide

## 📋 Table of Contents
1. [System Requirements](#system-requirements)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Database Setup](#database-setup)
5. [Deployment](#deployment)
6. [Troubleshooting](#troubleshooting)

---

## System Requirements

- **Python:** 3.10+
- **Node.js:** 18+ (for web frontend)
- **PostgreSQL:** 13+ (for database)
- **Solana:** Mainnet API access or RPC endpoint
- **Git:** For version control

### External Services Needed
1. **Telegram Bot Token** - From BotFather (@BotFather on Telegram)
2. **Solana Wallet** - Owner wallet with private key
3. **PostgreSQL Database** - Local or cloud instance
4. **Groq API Key** - For AI chat (optional)
5. **SMTP Credentials** - For email service (optional)

---

## Installation

### 1. Clone & Setup Environment

```bash
# Clone the repository
git clone <your-repo-url> redluck-lotto
cd redluck-lotto

# Create Python virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install Python dependencies
pip install -r requirements.txt

# Setup web frontend
cd redluck-lotto-web
npm install
cd ..
```

### 2. Create Environment File

```bash
# Copy example configuration
cp .env.example .env

# Edit .env with your actual values
nano .env
```

---

## Configuration

### Required Environment Variables

#### Telegram Bot
```
BOT_TOKEN=                    # Get from @BotFather
BOT_ADMIN=                    # Your Telegram user ID
```

#### Solana Blockchain
```
SOLANA_RPC_URL=               # Solana RPC endpoint
OWNER_WALLET_PRIVATE_KEY=     # Owner wallet private key (hex or JSON array)
OWNER_WALLET_ADDRESS=         # Owner public wallet address
```

#### Database
```
DATABASE_URL=postgresql://user:pass@localhost:5432/redluck_lotto
ENCRYPTION_KEY=               # Min 32 characters (for private key encryption)
```

#### Optional Services
```
GROQ_API_KEY=                 # For AI chat assistance
FROM_EMAIL=                   # For email notifications
SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD  # Email config
ANNOUNCEMENTS_GROUP_ID=       # Telegram group for announcements
```

---

## Database Setup

### Option 1: Local PostgreSQL

```bash
# Create database
createdb redluck_lotto

# Run schema setup (if provided)
psql redluck_lotto < schema.sql

# Or use SQLAlchemy auto-migration
python -c "from db import init_db; init_db()"
```

### Option 2: Cloud PostgreSQL (Neon, AWS RDS, etc.)

1. Create PostgreSQL instance
2. Get connection string
3. Set `DATABASE_URL` in .env
4. Run schema initialization

### Verify Connection

```bash
python << 'PYEOF'
from db import get_db_conn
try:
    conn = get_db_conn()
    print("✅ Database connection successful!")
    conn.close()
except Exception as e:
    print(f"❌ Database error: {e}")
PYEOF
```

---

## Deployment

### Option 1: Local Development

```bash
# Terminal 1: Start the bot
python main.py

# Terminal 2: Start web frontend
cd redluck-lotto-web
npm run dev
```

### Option 2: Railway / Render / Heroku

1. Push code to GitHub
2. Connect repository to deployment platform
3. Set environment variables in platform dashboard
4. Deploy

**Key Deployment Settings:**
- **Start Command:** `python main.py`
- **Python Version:** 3.10+
- **Memory:** 512MB minimum

### Option 3: Docker

```dockerfile
FROM python:3.10-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```

```bash
docker build -t redluck-lotto .
docker run -e BOT_TOKEN=xxx -e DATABASE_URL=xxx redluck-lotto
```

---

## Project Structure

```
redluck-lotto/
├── main.py                    # Main bot application
├── db.py                      # Database layer
├── encryption.py              # Private key encryption
├── email_service.py           # Email notifications
├── health_server.py           # Health check endpoint
├── info.py                    # Project info
├── ai/
│   ├── __init__.py
│   ├── ai_client.py           # AI chat client (Groq)
│   └── prompts.py             # AI system prompts
├── redluck-lotto-web/         # Web frontend (React/Vite)
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── src/
│   │   ├── main.jsx
│   │   ├── pages/
│   │   └── components/
│   └── public/
├── requirements.txt           # Python dependencies
├── .env.example              # Example environment config
└── SETUP_GUIDE.md            # This file
```

---

## Core Features

### 🎯 Lottery System
- **24 hourly draws** per day (one every hour)
- **3-tier prize system:** 5-match (70%), 4-match (20%), 3-match (10%)
- **Rollover mechanism:** Unclaimed tiers carry forward
- **Solana blockchain** for transparency

### 💰 Wallet Management
- Create bot-managed wallets
- Import existing wallets with private keys
- Connect external wallets (Phantom, Solflare)
- Max 3 wallets per user
- Encrypted private key storage

### 🏆 VIP System
- Bronze: 0-1 SOL
- Silver: 1-5 SOL
- Gold: 5-20 SOL
- Platinum: 20-50 SOL
- Diamond: 50+ SOL

### 📊 Transparency Dashboard
- Real-time statistics from payout_logs
- Recent draw results with winning/picked numbers
- Top winners leaderboard
- Historical data tracking

### 🤖 AI Assistant
- Powered by Groq (Llama 3.1)
- Answers gameplay questions
- Explains lottery mechanics
- Provides wallet assistance
- Support guidance

---

## Testing

### Test the Bot Locally

```bash
# 1. Verify Python environment
python main.py

# 2. Check database connection
python -c "from db import get_db_conn; print('✅ DB OK' if get_db_conn() else '❌ DB Failed')"

# 3. Check Solana connection
python << 'PYEOF'
import asyncio
from main import OWNER_WALLET
print(f"✅ Wallet: {OWNER_WALLET}")
PYEOF

# 4. Test Telegram bot
# Send /start to your bot on Telegram
```

### Common Issues

| Issue | Solution |
|-------|----------|
| `DATABASE_URL not set` | Copy .env.example to .env and configure |
| `OWNER_WALLET_PRIVATE_KEY missing` | Add your Solana private key to .env |
| `Telegram bot not responding` | Check BOT_TOKEN is correct |
| `Connection refused (PostgreSQL)` | Ensure PostgreSQL is running and DATABASE_URL is correct |

---

## Production Checklist

- [ ] Environment variables configured
- [ ] Database initialized and tested
- [ ] Solana wallet funded with initial SOL
- [ ] Telegram bot token obtained
- [ ] SSL/HTTPS configured for web frontend
- [ ] Backups configured for database
- [ ] Error monitoring setup (Sentry, etc.)
- [ ] Rate limiting enabled
- [ ] Security headers configured

---

## Support & Documentation

### Key Files to Review
- `main.py` - Bot logic and Telegram handlers
- `db.py` - Database schema and queries
- `ai/prompts.py` - AI system prompts and FAQ
- `redluck-lotto-web/` - Web interface code

### Getting Help
1. Check the Telegram bot /help command
2. Review relevant code sections
3. Check database logs for errors
4. Enable DEBUG=true for verbose logging

---

## License & Attribution

RedLuck Lotto - Cryptocurrency Lottery on Solana
Built with Python, PostgreSQL, and React

---

**Last Updated:** December 2024
**Version:** 1.0
