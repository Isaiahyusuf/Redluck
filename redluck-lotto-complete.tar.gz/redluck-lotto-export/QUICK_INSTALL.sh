#!/bin/bash
# RedLuck Lotto - Quick Installation Script

set -e

echo "🚀 RedLuck Lotto - Quick Installation"
echo "======================================"

# Check Python version
echo "✓ Checking Python version..."
python3 --version || (echo "❌ Python 3 not found"; exit 1)

# Create virtual environment
echo "✓ Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install dependencies
echo "✓ Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Web setup
echo "✓ Setting up web frontend..."
cd redluck-lotto-web
npm install 2>/dev/null || echo "⚠️ Node/npm not found - web frontend skipped"
cd ..

# Environment file
if [ ! -f .env ]; then
    echo "✓ Creating .env file from template..."
    cp .env.example .env
    echo "⚠️  Please edit .env with your credentials"
else
    echo "✓ .env file already exists"
fi

echo ""
echo "✅ Installation complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env with your configuration:"
echo "   - BOT_TOKEN (from @BotFather)"
echo "   - DATABASE_URL (PostgreSQL connection)"
echo "   - OWNER_WALLET_PRIVATE_KEY (Solana private key)"
echo "   - ENCRYPTION_KEY (any random 32+ character string)"
echo ""
echo "2. Initialize database:"
echo "   python main.py"
echo ""
echo "3. To start the bot:"
echo "   source venv/bin/activate"
echo "   python main.py"
echo ""
echo "For more details, see SETUP_GUIDE.md"
