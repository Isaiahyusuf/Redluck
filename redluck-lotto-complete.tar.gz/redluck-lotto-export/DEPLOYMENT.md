# 🚀 Deployment Guide for RedLuck Lotto

## Quick Deploy Options

### Option 1: Railway (Recommended - 5 minutes)

1. **Create Railway Account**
   - Go to https://railway.app
   - Sign up with GitHub

2. **Create New Project**
   - Click "New Project"
   - Select "Deploy from GitHub repo"
   - Connect your GitHub account
   - Choose `redluck-lotto` repository

3. **Set Environment Variables**
   In Railway dashboard, add:
   ```
   BOT_TOKEN=your_token_here
   DATABASE_URL=postgresql://...
   OWNER_WALLET_PRIVATE_KEY=your_key_here
   ENCRYPTION_KEY=your_encryption_key
   GROQ_API_KEY=your_groq_key
   ```

4. **Deploy**
   - Railway auto-deploys on push to main
   - View logs in dashboard
   - Bot runs 24/7

### Option 2: Render (Also Easy)

1. Go to https://render.com
2. Click "New +" > "Web Service"
3. Connect GitHub repository
4. Set build command: `pip install -r requirements.txt`
5. Set start command: `python main.py`
6. Add environment variables
7. Deploy

### Option 3: Heroku (Legacy but Works)

```bash
# Install Heroku CLI
curl https://cli.heroku.com/install.sh | sh

# Login and create app
heroku login
heroku create redluck-lotto
heroku addons:create heroku-postgresql:standard-0

# Set environment variables
heroku config:set BOT_TOKEN=xxx
heroku config:set DATABASE_URL=xxx
# ... set all required vars

# Deploy
git push heroku main

# View logs
heroku logs --tail
```

### Option 4: Docker + VPS

```bash
# Build image
docker build -t redluck-lotto .

# Run container
docker run -d \
  -e BOT_TOKEN=xxx \
  -e DATABASE_URL=xxx \
  -p 8080:8080 \
  redluck-lotto

# With docker-compose
docker-compose up -d
```

### Option 5: Direct VPS (Ubuntu/Debian)

```bash
# 1. Install dependencies
sudo apt update
sudo apt install python3.10 python3-pip postgresql

# 2. Clone repository
git clone <repo-url> /opt/redluck-lotto
cd /opt/redluck-lotto

# 3. Setup Python environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 4. Create systemd service
sudo tee /etc/systemd/system/redluck-lotto.service << EOL
[Unit]
Description=RedLuck Lotto Bot
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/redluck-lotto
EnvironmentFile=/opt/redluck-lotto/.env
ExecStart=/opt/redluck-lotto/venv/bin/python main.py
Restart=always

[Install]
WantedBy=multi-user.target
EOL

# 5. Enable service
sudo systemctl daemon-reload
sudo systemctl enable redluck-lotto
sudo systemctl start redluck-lotto

# 6. Check status
sudo systemctl status redluck-lotto
sudo journalctl -u redluck-lotto -f
```

## Environment Variables Needed

### Critical (Required)
```
BOT_TOKEN                     # Telegram bot token
DATABASE_URL                  # PostgreSQL connection
OWNER_WALLET_PRIVATE_KEY      # Solana wallet key
ENCRYPTION_KEY                # Min 32 characters
```

### Solana (Required)
```
OWNER_WALLET_ADDRESS          # Your public wallet
SOLANA_RPC_URL                # RPC endpoint (or use default)
```

### Optional but Recommended
```
GROQ_API_KEY                  # For AI assistant
FROM_EMAIL                    # For email notifications
SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD
```

## Database Setup

### Railway/Render (Auto)
- They provide PostgreSQL automatically
- Set DATABASE_URL in environment
- No manual setup needed

### Self-Hosted PostgreSQL

```bash
# Create database
sudo -u postgres createdb redluck_lotto

# Create user
sudo -u postgres psql << EOL
CREATE USER redluck_user WITH PASSWORD 'strong_password';
GRANT ALL PRIVILEGES ON DATABASE redluck_lotto TO redluck_user;
EOL

# Set DATABASE_URL
DATABASE_URL="postgresql://redluck_user:strong_password@localhost:5432/redluck_lotto"
```

## Monitoring & Logs

### Railway
- Logs available in dashboard
- Set alerts for crashes
- Memory and CPU monitoring included

### Render
- Real-time logs in dashboard
- Auto-restart on crash
- Health checks built-in

### Self-Hosted
```bash
# View logs
tail -f /var/log/redluck-lotto.log

# Monitor process
ps aux | grep main.py

# Check system resources
top -p $(pgrep -f main.py)
```

## Scaling Considerations

### Single Instance (Good for <10k users)
- One bot instance running
- PostgreSQL on separate server
- Works fine for most use cases

### Multiple Instances (For >10k users)
- Load balance across multiple bots
- Shared PostgreSQL database
- Redis for cache (optional)
- Message queue for transactions

## Backup Strategy

### Database Backups
```bash
# Daily backup script
pg_dump redluck_lotto | gzip > backup_$(date +%Y%m%d).sql.gz

# Or using cloud provider backups
# Railway: Automatic
# Render: Automatic
# AWS RDS: Automatic snapshots
```

### Code Backups
- Keep repo on GitHub
- Tag releases
- Maintain changelog

## SSL/HTTPS (For Web Frontend)

### Railway/Render
- Automatic HTTPS
- Free SSL certificates
- No configuration needed

### Self-Hosted
```bash
# Using Let's Encrypt with Nginx
sudo apt install nginx certbot python3-certbot-nginx

# Obtain certificate
sudo certbot certonly --nginx -d yourdomain.com

# Configure Nginx to reverse proxy
# See nginx.conf template
```

## Performance Optimization

### Database
- Index frequently queried columns
- Use connection pooling
- Regular VACUUM and ANALYZE

### Bot
- Enable response caching (already done)
- Batch database operations
- Use async/await for I/O

### Web Frontend
- Enable gzip compression
- Use CDN for static assets
- Minify JavaScript/CSS

## Security Checklist

- [ ] BOT_TOKEN is secret (never commit to repo)
- [ ] DATABASE_URL uses strong password
- [ ] ENCRYPTION_KEY is random (32+ chars)
- [ ] OWNER_WALLET_PRIVATE_KEY is encrypted at rest
- [ ] Environment variables not logged
- [ ] HTTPS enabled for web frontend
- [ ] Database has automated backups
- [ ] Rate limiting enabled on API
- [ ] Error messages don't expose sensitive data
- [ ] Regular security audits scheduled

## Troubleshooting Deployment

| Issue | Solution |
|-------|----------|
| Bot doesn't start | Check logs, verify BOT_TOKEN |
| Database connection error | Verify DATABASE_URL, check PostgreSQL |
| High memory usage | Reduce cache, check for memory leaks |
| Slow responses | Check database indexes, optimize queries |
| Crashes after deploy | Check .env variables are still set |

## CI/CD with GitHub Actions

```yaml
name: Deploy to Railway

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to Railway
        env:
          RAILWAY_TOKEN: ${{ secrets.RAILWAY_TOKEN }}
        run: |
          npm i -g @railway/cli
          railway up
```

## Monitoring Services (Optional)

- **Sentry:** Error tracking
- **LogRocket:** Session replay
- **DataDog:** Infrastructure monitoring
- **New Relic:** Performance monitoring

## Cost Estimates (Monthly)

| Service | Cost |
|---------|------|
| Railway (starter) | $5-15 |
| PostgreSQL (Railway) | $12 |
| Groq API | Free tier available |
| Domain | $12 |
| SSL Certificate | Free |
| **Total** | **~$30/month** |

## Next Steps

1. Choose deployment platform
2. Set up database
3. Configure environment variables
4. Deploy code
5. Test bot functionality
6. Set up monitoring
7. Configure backups
8. Document any custom changes

---

**Ready to deploy?** Start with Railway - it's the easiest! 🚀
